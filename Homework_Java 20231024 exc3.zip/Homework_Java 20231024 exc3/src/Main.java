import java.util.Arrays;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random r = new Random();
        int[] Massiv = new int[8];
        for (int i = 0; i < Massiv.length; i++) {
            Massiv[i] = r.nextInt(1, 50);
            String asString = Arrays.toString(Massiv);
            System.out.println(asString);
        }
        for (int i = 0; i < Massiv.length; i +=2 ) {
            Massiv[i] =0;
            System.out.println(Massiv[i]);
        }
        Arrays.sort(Massiv);
        System.out.println(Arrays.toString(Massiv));

    }

}

//Задание 3.
//Создайте массив из 8 случайных целых чисел из интервала [1;50]
//Выведите массив в консоль в строку.
//Замените каждый элемент с нечетным индексом на ноль.
//Снова выведете массив в консоль в отдельной строке.
//Отсортируйте массив по возрастанию.
//Снова выведете массив в консоль в отдельной строке.